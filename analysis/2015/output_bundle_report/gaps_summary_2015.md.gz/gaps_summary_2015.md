# EURUSD 2015 — Anomalous Gaps (M5)

| # | gap_start (UTC) | gap_end (UTC) | length_min |
|---:|---|---|---:|
| 1 | 2015-08-21 18:20:00 | 2015-08-21 19:00:00 | 40 |
