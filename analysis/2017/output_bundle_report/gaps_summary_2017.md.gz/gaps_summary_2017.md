# EURUSD 2017 — Anomalous Gaps (M5)

| # | gap_start (UTC) | gap_end (UTC) | length_min |
|---:|---|---|---:|
