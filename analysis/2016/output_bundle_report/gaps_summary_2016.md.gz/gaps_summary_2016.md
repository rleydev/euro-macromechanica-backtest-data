# EURUSD 2016 — Anomalous Gaps (M5)

| # | gap_start (UTC) | gap_end (UTC) | length_min |
|---:|---|---|---:|
| 1 | 2016-12-26 07:00:00 | 2016-12-26 23:00:00 | 960 |
