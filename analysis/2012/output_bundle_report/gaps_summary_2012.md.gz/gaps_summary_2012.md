# EURUSD 2012 — Anomalous Gaps (M5)

| # | gap_start (UTC) | gap_end (UTC) | length_min |
|---:|---|---|---:|
| 1 | 2012-09-10 22:05:00 | 2012-09-10 22:15:00 | 10 |
