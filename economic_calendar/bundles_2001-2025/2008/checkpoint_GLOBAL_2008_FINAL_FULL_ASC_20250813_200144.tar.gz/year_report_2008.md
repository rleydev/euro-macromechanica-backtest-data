# Year Report — 2008
_Generated at (UTC): 2025-08-13T20:01:43Z_
- Total events: **297**
- Date range (UTC): 2008-01-01 09:00:00+00:00 → 2008-12-31 10:00:00+00:00
- Events by country: {'US': 125, 'EA': 99, 'UK': 64, 'CH': 9}
- Impact distribution: {'high': 149, 'medium': 148}
- Authenticity (official sources): **100.0%** (297/297)
- Source breakdown: CB **54.2%** (161/297), STAT **45.8%** (136/297), Other **0.0%** (0/297)

## Backtest Suitability
- Score: **100.0/100**
- Heuristic: ≥80 — готов к продакшн-бэктесту; 60–79 — исследовательский; <60 — требует доочистки.

## Archives
- calendar: calendar_2008.csv.gz — 5315 bytes
- bundle: bundle_2008.tar.gz — 4982 bytes

---
*Built by core.py (flat edition).*
