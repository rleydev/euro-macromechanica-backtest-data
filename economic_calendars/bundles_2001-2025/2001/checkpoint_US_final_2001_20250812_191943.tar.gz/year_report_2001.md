# Year Report — 2001
_Generated at (UTC): 2025-08-12T19:19:35Z_
- Total events: **275**
- Date range (UTC): 2001-01-01 08:00:00+00:00 → 2001-12-31 10:00:00+00:00
- Events by country: {'US': 118, 'EA': 86, 'UK': 64, 'CH': 7}
- Impact distribution: {'high': 168, 'medium': 107}
- Authenticity (official sources): **89.5%** (246/275)
- Source breakdown: CB **26.5%** (73/275), STAT **62.9%** (173/275), Other **10.5%** (29/275)

## Backtest Suitability
- Score: **90.0/100**
- Heuristic: ≥80 — готов к продакшн-бэктесту; 60–79 — исследовательский; <60 — требует доочистки.

## Archives
- checkpoint: checkpoint_2001_FINAL_20250812_180607.tar.gz — 38646 bytes

---
*Built by core.py (flat edition).*
