# Year Report — 2004
_Generated at (UTC): 2025-08-13T14:43:15Z_
- Total events: **278**
- Date range (UTC): 2004-01-01 09:00:00+00:00 → 2004-12-31 10:00:00+00:00
- Events by country: {'US': 118, 'EA': 100, 'UK': 52, 'CH': 8}
- Impact distribution: {'high': 167, 'medium': 111}
- Authenticity (official sources): **100.0%** (278/278)
- Source breakdown: CB **56.8%** (158/278), STAT **43.2%** (120/278), Other **0.0%** (0/278)

## Backtest Suitability
- Score: **100.0/100**
- Heuristic: ≥80 — готов к продакшн-бэктесту; 60–79 — исследовательский; <60 — требует доочистки.

## Archives
- calendar: calendar_2004.csv.gz — 4163 bytes

---
*Built by core.py (flat edition).*
